/**
 * @file variogram.h
 * @brief declaration: variogram class
 * @author Tomohiko Mukai
 */
#ifndef	VARIOGRAM_HEADER_FILE_
#define	VARIOGRAM_HEADER_FILE_

#include <vector>
#include <cmath>

/**
 * @class CVariogram Variogram.h
 * @brief experimental/theoretical variogram class
 * @author Tomohiko Mukai
 */
class CVariogram
{
//
// member enumeration
public:
	/**
	 *	@enum VariogramModel
	 */
	enum VariogramModel
	{
		//! not estimated
		VARIO_NONE,
		//! spherical model
		VARIO_SPH,
		//! stable model
		VARIO_STB,
		//! number of models
		VARIO_NUM
	};

//
// member classes
public:
	/**
	 * @struct VarioItm
	 * @brief structure of distance and dissimilarity
	 */
	struct VarioItm
	{
		//! distance
		double distance;
		//! dissimilarity
		double dissimilarity;
	};

//
// variables
private:
	//! theoretical variogram model
	int m_model;

	//
	// papameters of theoretical variogram
	//
	//! nugget
	double m_nugget;
	//! sill
	double m_sill;
	//! range
	double m_range;
	//! power coefficient of stable model
	double m_power;

	size_t m_samples;
	double *m_pDistance;
	double *m_pVariogram;

//
// constructor / destructor
//
public:
	// default constructor
	CVariogram(void);
	bool allocate(size_t);
	// destructor
	virtual ~CVariogram(void);

	bool draw(void);

//
// attributes
public:

	/**
	 * @fn double spherical(double n, double s, double r, double d)
	 * @brief spherical variogram model
	 * @param n [in] nugget
	 * @param s [in] sill
	 * @param r [in] range
	 * @param d [in] distance
	 * @return dissimilarity
	 */
	double spherical(double n, double s, double r, double d) const
	{
		if (d > r)
			return  s;
		return n + (s-n) * (3.0 / 2.0 * fabs(d) / r - pow(fabs(d) / r, 3.0) / 2);
	}

	/**
	 * @fn double stable(double n, double s, double r, double p, double d)
	 * @brief stable model variograms
	 * @param n [in] nugget
	 * @param s [in] sill
	 * @param r [in] range
	 * @param p [in] power coefficient of stable models
	 * @param d [in] distance
	 * @return dissimilarity
	 */
	double stable(double n, double s, double r, double p, double d) const
	{
		double t = pow(d / r, p);
		if (t >= 700.0)
			return n + s;
		return n + s * (1.0 - exp(-t));
	}


	/**
	 *	@fn double nugget(void) const
	 *	@return nugget
	 */
	double nugget(void) const
		{
			return m_nugget;
		}
	/**
	 *	@fn double sill(void) const
	 *	@return sill
	 */
	double sill(void) const
		{
			return m_sill;
		}
	/**
	 *	@fn double range(void) const
	 *	@return range
	 */
	double range(void) const
		{
			return m_range;
		}
	/**
	 *	@fn double power(void) const
	 *	@return power coefficient (only for stable models)
	 */
	double power(void) const
		{
			return m_power;
		}

 	size_t samples(void) const
	{
		return m_samples;
	}
	double maxDistance(void) const
	{
		return m_pDistance[m_samples - 1];
	}
	double minDistance(void) const
	{
		return m_pDistance[0];
	}
	bool isActive(void) const
	{
		return m_pDistance != NULL && m_pVariogram;
	}

	/**
	 *	@fn int modelType(void) const
	 *	@return type of theoretical variogram
	 */
	int modelType(void) const
	{
		return m_model;
	}
	// get number of samples whose distance is less than given value
//
// data reader
public:
	// get theoretical dissimilarity
	double getModelData(double dist) const;
	// get covariance corresponding to theoretical dissimilarity
	double getModelCovariance(double dist) const;
	// get sample data (distance & dissimilarity)
	bool getSample(size_t smpl, double &dist, double &vario) const;

      
//
// data writer
public:
	// set sample data (distance & dissimilarity)
	bool setSample(const std::vector<CVariogram::VarioItm> &vecSample);
	// set parameters of theoretical variogram (nugget, sill, range, power, and so on)
	bool setModel(int model, double nugget, double sill, double range, double power);

//
// manipulator
protected:
	// sort container for dissimilarity by distance
	bool sortByDistance(void);
	

//
// memory manager
private:
	// memory destruction
	void destroy(void);
};




#endif	//VARIOGRAM_HEADER_FILE_
