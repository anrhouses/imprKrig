/**
 * @file geostat.h
 * @brief declaration : imprecise kriging predictor class
 * @author Kevin Loquin
 */
#ifndef	GEOSTATISTICS_CLASS_HEADER_FILE_
#define	GEOSTATISTICS_CLASS_HEADER_FILE_

#include "variogram.hpp"

#include <vector>
#include <cmath>
#include <list>
#include <utility>
#include <ctime>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>


double isoDist(const gsl_vector *, const gsl_vector *);
/**
 * @class CGeostat
 * @brief kriging class
 * @author Kevin Loquin
 */

class CGeostat
{

//
// variables
private:
	//! coordinates
	std::vector<gsl_vector *> m_coords;
	//! variogram parameters imprecise bounds
	gsl_vector * m_parameters;
	//! variogram parameters imprecise bounds
	std::vector<gsl_vector *> m_parameters_bounds;
	//! sample dataset
	gsl_vector *m_pData;
	//! sample dataset imprecise bounds
	std::vector<gsl_vector *> m_data_bounds;
	//! control space domain
	std::vector< std::pair<double, double> > m_domain;
	//! theoretical variogram
	CVariogram* m_pVariogram;
	//! cloud variogram
	CVariogram* m_pVarioCloud;
	//! precomputed kriging system
	gsl_matrix* m_pOKSys;
	//! data file path
	char * data_file_path;
	//! data nature identifier (precise = 1; interval=2; fuzzy=3)
	size_t data_nature;
	//! variogram nature identifier (precise = 1; interval=2; fuzzy=3)
	size_t vario_nature;
	//! number of simulations in the simulated annealing method
	size_t n_simulations;
	


//
// constructors/destructor
public:
	// constructor
	CGeostat(void);
	// destructor
	virtual ~CGeostat(void);
	// initializers
  /*	bool initialize_data_file();
	bool initialize_data();
	bool initialize_domain();
	bool initialize_variogram();
	bool initialize_simulations_number();
  */
//
// attributes (const)
public:
	/**
	 *	@fn bool isActive(void) const
	 *	@retval true active
	 *	@retval false inactive
	 */
	bool isActive(void) const
		{
			return m_pData != NULL;
		}
	/**
	 *	@fn size_t samples(void) const
	 *	@return number of samples
	 */
	size_t samples(void) const
		{
			return m_pData->size;
		}
	size_t simulations(void) const
		{
			return n_simulations;
		}	


	/**
	 *	@fn size_t dimension(void) const
	 *	@return dimension of control space
	 */
	size_t dimension(void) const
		{
			return m_domain.size();
		}

	
	double probaAcceptance(double e,double eNew, double T)
		{
			double result = 1.0;
			if(eNew > e)
				result = exp((e-eNew)/T);
			//std::cout << "proba: " << result << std::endl;
			return result;
		}


	// maximum distance in control space
	double maxDist(void) const;
	// domain validation
	bool isDomain(const gsl_vector *c) const;
	
//
// data readers
//
public:
	// get coordinate of s-th data
	bool getCoordinate(gsl_vector *c, size_t s) const;
	// get coordinates vectors X and Y in the same order
	bool getCoordinates(gsl_vector *X, gsl_vector *Y) const;
	// get s-th data
	double getData(size_t s) const;
	// get s-th imprecise data
	bool getImpreciseData(gsl_vector *c, size_t s) const;
	// get data nature
	size_t get_data_nature() const;
	// get s-th imprecise variogram parameter
	bool getImpreciseVariogramParameter(gsl_vector *c, size_t s) const;
	// get s-th variogram parameter
	double getVariogramParameter( size_t s) const;
	// get parameters of estimated theoretical variogram
	bool getModelParameters(double &sill, double &range, double &nugget, double &power) const;
	// get variogram nature
	size_t get_vario_nature() const;
	// get optimum weights vector for target parameter c
	bool getWeightVector(gsl_vector *w, const gsl_vector *c) const;
	// get optimum weight for the s-th data for target parameter c
	double getWeight(size_t s, const gsl_vector *c) const;
	// get prediction value & estimate variance
	bool getPredictData(double &pred, double &var, const gsl_vector *c) const;
	// get imprecise prediction value for precise variogram parameters
	bool getOptimalImprecisePrediction(gsl_vector *pred, const gsl_vector *c) const;
	// get prediction value with weight
	bool getPredictData(double &pred, const gsl_vector *w) const;
	// get control space domain
	bool getDomain(gsl_vector *lower, gsl_vector *upper) const;
	// set parameters of theoretical variogram (nugget, sill, range, power, and so on)
	bool precomputeKrigingSystemFromOutSide();

	bool isOnADataPosition(const gsl_vector *c, size_t *data_index);

	void display();
	// compute variogram cloud
	std::vector<CVariogram::VarioItm> computeVariogramCloud(void) const;
	// compute experimental variogram
	std::vector<CVariogram::VarioItm> computeExperimentalVariogram(const std::vector<CVariogram::VarioItm> &vcloud, double step) const;
	
	/// get the imprecise kriging estimate for an exploration of the variogram parameters and data domains by simulated annealing with n simulations at position c
	void getOptimumBound_simulated_annealing(gsl_vector * ,const gsl_vector *);
	/// get the imprecise kriging estimate for the variogram parameters and data domains bounds  at position c
	void getOptimumBound_bounds_combinatorial(gsl_vector * , const gsl_vector *);
	/// get the imprecise kriging estimate for the hybrid method at position c
	void getOptimumBound_hybrid(gsl_vector * , const gsl_vector *);
//
// data writers
public:
	// memory allocation
	bool allocate(size_t smpl, size_t dim);
        // set control space domain
	bool setDomain(const gsl_vector *, const gsl_vector *);
        // set control space domain automatically
	bool setDomain();
	// set coordinate of sample s
	bool setCoordinate(size_t , const gsl_vector *);
	// set sample data
	bool setData(size_t , double );
  	// set sample data
	bool setDataNature(size_t);
	// set sample imprecise data
	bool setImpreciseData(size_t , const gsl_vector *);
	// set imprecise variogram parameter
	bool setImpreciseVariogramParameter(size_t , const gsl_vector *);
	// set variogram parameter
	bool setVariogramParameter(size_t , double);
	// set simulation number
	bool setSimulation(size_t);
	

// calculators
protected:
	// precompute kriging system
	bool precomputeKrigingSystem( double, double, double);
	
//
// memory managers
private:
	// memory destruction
	void destroy(void);
	

};

#endif	//GEOSTATISTICS_CLASS_HEADER_FILE_
