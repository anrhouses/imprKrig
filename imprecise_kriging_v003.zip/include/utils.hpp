/**
 * @file utils.hpp
 * @brief utilities for imprecise_kriging application
 * @author Kevin Loquin
 */
 
 
 
#ifndef	UTILS_HEADER_FILE_
#define	UTILS_HEADER_FILE_

#include <mex.h>
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string.h>
#include <cmath>
#include <cfloat>
#include <sstream>


#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_sort_vector.h>
#include <gsl/gsl_permute_vector.h>
#include <gsl/gsl_combination.h>
#include <gsl/gsl_sort.h>

using namespace std;

/*
#define ALLOCATION_KO 0
#define ALLOCATION_OK 1
#define TERMINE 2

#define ALLOCATION(N,type) (type *)mxCalloc(N,sizeof(type))  // pour mexFunction
// #define ALLOCATION(N,type) (type *)malloc(N*sizeof(type))  // pour C windows
// #define ALLOCATION(N,type) new type [N]   // pour C++ windows
#define DESALLOCATION(pointeur) if(pointeur!=NULL) mxFree(pointeur)  // pour mexFunction
// #define DESALLOCATION(pointeur) free(pointeur)   // pour C windows
// #define DESALLOCATION(pointeur) delete pointeur   // pour C++ windows

#define EPSILON 1e-32


#define Fabs(a) ( ( (a) > 0.0 ) ? (a) : (-(a)) )
#define Min(a,b) ( ( (a) < (b) ) ? (a) : (b) )
#define Max(a,b) ( ( (a) > (b) ) ? (a) : (b) )
*/

extern char * convertDouble(double number);
extern char * convertInt(int number);
extern void initOutFile(ofstream * outFile, const char * currentFileName);
extern void initInFile(ifstream * inFile, const char * currentFileName);
extern size_t countData(const char * dataFileName);
extern double sum_points(const gsl_vector *weights, const gsl_vector *data);
extern double get_sum_bound(const gsl_vector *Z,const gsl_vector *inf_weights,const gsl_vector *sup_weights, bool isInf);
extern void sum_intervals_under_constraint(gsl_vector * result, const gsl_vector *inf_weights, const gsl_vector *sup_weights, const gsl_vector *inf_data, const gsl_vector *sup_data);



#endif // end
