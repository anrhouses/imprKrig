#ifndef FINTER_DEFINED
#define FINTER_DEFINED

#include <map>
#include <string>

#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>

#include "fuzzyintervalbycuts.hpp"




struct alphaCut
{
    gsl_vector * cut;
    double alpha;
};




class Finter
{
  double (*membership) (double);
  double delta;
  double mode;

public:
	// constructor
	Finter(void);
	void initialize(const char * , double , double);
		// initializer
	double membershipdegree(double);
//	void extract_cuts(alphaCut*, size_t);
//	void extract_cuts_leftright(gsl_vector*, alphaCut*, alphaCut*, size_t);
	void extract_cut(gsl_vector*, double);
	
	void to_FinteralphaCut(FinteralphaCut*);
	void to_FinteralphaCut_leftright(gsl_vector*, FinteralphaCut*, FinteralphaCut*);
	
};


#endif
