#ifndef FINTERBYCUTS_DEFINED
#define FINTERBYCUTS_DEFINED

#include <map>
#include <string>

#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>




class FinteralphaCut
{
    gsl_matrix * cut;
    double * alpha;


public:
	// constructor
	FinteralphaCut(void);
	
	// initializer (allocator)
	void dynalloc(size_t);
	
	//desallocator
	void free_alphaCut(); 
	
	void save_in(char * ); 
	
	size_t getnbCuts();
	
	gsl_vector * get_cut(size_t);
	
	void set_cut(const gsl_vector *, size_t);
	void set_alpha(double, size_t );
	void set_cut(const gsl_vector *,double, size_t);
	
	void display();
	
	/*double membershipdegree(double);
	void extract_cuts(alphaCut*, size_t);
	void extract_cuts_leftright(gsl_vector*, alphaCut*, alphaCut*, size_t);
	void extract_cut(gsl_vector*, double);*/
};


#endif
